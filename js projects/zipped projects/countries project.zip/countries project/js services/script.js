
import { countries } from "./countriesService.js";
import { createCards } from "./domService.js";

console.log(countries);
createCards();
